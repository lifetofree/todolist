/* ===== Todo PWA — HTML/CSS/JS ธรรมดา + localStorage ===== */
/* ไม่มี framework ไม่มี server: ข้อมูลทั้งหมดเก็บในเบราว์เซอร์ของผู้ใช้ */
(function () {
  'use strict';

  const STORAGE_KEY = 'todo-pwa.tasks';

  const form = document.getElementById('todo-form');
  const input = document.getElementById('todo-input');
  const listEl = document.getElementById('todo-list');
  const emptyEl = document.getElementById('empty-state');
  const countEl = document.getElementById('task-count');

  let tasks = loadTasks();

  /* SVG ประกอบ (คงที่ ไม่มีข้อมูลผู้ใช้ จึงปลอดภัยต่อ XSS) */
  const CHECK_SVG =
    '<svg viewBox="0 0 24 24" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>';
  const X_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';

  const makeId = () =>
    Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  /* ---------- localStorage ---------- */
  function loadTasks() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const data = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(data)) return [];
      return data
        .filter((t) => t && typeof t.text === 'string' && t.text.trim() !== '')
        .map((t) => ({
          id: (t.id == null ? '' : String(t.id)).replace(/[^a-zA-Z0-9_-]/g, '') || makeId(),
          text: t.text,
          done: !!t.done,
        }));
    } catch (err) {
      return []; /* ข้อมูลเสีย หรือ storage ใช้ไม่ได้ — เริ่มใหม่แทนที่จะพังทั้งแอป */
    }
  }

  function saveTasks() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (err) {
      /* เช่นโหมดไม่ระบุตัวตนเต็มพื้นที่ — หน้านี้ยังใช้งานได้ตามปกติ */
    }
  }

  /* ---------- สร้าง DOM ของงาน 1 แถว (ใช้ textContent กัน XSS) ---------- */
  function createItem(task) {
    const li = document.createElement('li');
    li.className = 'todo-item' + (task.done ? ' done' : '');
    li.dataset.id = task.id;

    const check = document.createElement('button');
    check.type = 'button';
    check.className = 'check';
    check.setAttribute(
      'aria-label',
      task.done ? 'ยกเลิกเครื่องหมายเสร็จ' : 'ทำเครื่องหมายว่าเสร็จแล้ว'
    );
    check.innerHTML = CHECK_SVG;

    const text = document.createElement('span');
    text.className = 'todo-text';
    text.textContent = task.text;

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'delete';
    del.setAttribute('aria-label', 'ลบงานนี้');
    del.innerHTML = X_SVG;

    li.append(check, text, del);
    return li;
  }

  /* ---------- แถบสรุป + สถานะว่าง ---------- */
  function refreshMeta() {
    const doneCount = tasks.filter((t) => t.done).length;
    countEl.textContent = 'เสร็จแล้ว ' + doneCount + '/' + tasks.length + ' งาน';
    emptyEl.hidden = tasks.length !== 0;
  }

  /* ---------- การทำงานหลัก ---------- */
  function addTask(rawText) {
    const text = rawText.trim();
    if (text === '') return false; /* เกณฑ์ 1: ข้อความว่างห้ามเพิ่ม */
    const task = { id: makeId(), text: text, done: false };
    tasks.unshift(task); /* งานใหม่ขึ้นบนสุด เห็นผลทันที */
    listEl.prepend(createItem(task));
    saveTasks();
    refreshMeta();
    return true;
  }

  function toggleTask(id) {
    const task = tasks.find((t) => t.id === id);
    if (!task) return;
    task.done = !task.done;
    const li = listEl.querySelector('[data-id="' + id + '"]');
    if (li) {
      li.classList.toggle('done', task.done);
      const check = li.querySelector('.check');
      if (check) {
        check.setAttribute(
          'aria-label',
          task.done ? 'ยกเลิกเครื่องหมายเสร็จ' : 'ทำเครื่องหมายว่าเสร็จแล้ว'
        );
      }
    }
    saveTasks();
    refreshMeta();
  }

  function removeTask(id) {
    tasks = tasks.filter((t) => t.id !== id);
    saveTasks(); /* บันทึกก่อนเสมอ ข้อมูลจึงถูกต้องแม้ปิดแท็บทันที */
    const li = listEl.querySelector('[data-id="' + id + '"]');
    if (li) {
      li.classList.add('removing'); /* เฟดออกก่อน แล้วค่อยถอดออกจาก DOM */
      setTimeout(() => li.remove(), 160);
    }
    refreshMeta();
  }

  function renderAll() {
    listEl.innerHTML = '';
    const frag = document.createDocumentFragment();
    tasks.forEach((t) => frag.appendChild(createItem(t)));
    listEl.appendChild(frag);
    refreshMeta();
  }

  /* ---------- อีเวนต์ ---------- */
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (addTask(input.value)) {
      input.value = '';
    } else {
      /* ว่าง/เว้นวรรคเท่านั้น ให้ช่องสั่นเตือนว่าไม่ได้เพิ่ม */
      input.classList.remove('shake');
      void input.offsetWidth; /* รีสตาร์ต animation */
      input.classList.add('shake');
    }
    input.focus();
  });

  /* คลิกที่ตัวงาน = ติ๊กเสร็จ (เกณฑ์ 2) ส่วนปุ่มลบแยกไว้ (เกณฑ์ 3) */
  listEl.addEventListener('click', (e) => {
    const li = e.target.closest('.todo-item');
    if (!li) return;
    if (e.target.closest('.delete')) {
      removeTask(li.dataset.id);
    } else {
      toggleTask(li.dataset.id);
    }
  });

  /* แท็บอื่นแก้ข้อมูลเดียวกัน ให้หน้านี้อัปเดตตามด้วย */
  window.addEventListener('storage', (e) => {
    if (e.key === STORAGE_KEY) {
      tasks = loadTasks();
      renderAll();
    }
  });

  /* ---------- เริ่มต้น ---------- */
  renderAll();
})();
